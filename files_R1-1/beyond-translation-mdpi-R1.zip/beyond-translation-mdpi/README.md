# Beyond Translation (Turkish-CBE) — MDPI *Information* submission

Build (pdfLaTeX + BibTeX):

    latexmk -pdf main.tex
    # or: pdflatex main && bibtex main && pdflatex main && pdflatex main

Layout:
- main.tex            entry point (front matter, MDPI statements, abbreviations)
- sections/*.tex      body sections and appendices
- references.bib      bibliography (rendered with Definitions/mdpi.bst)
- figures/            Figure 1 as editable TikZ source (figure1_architecture.tex);
                      Figures 2-6 as the original vector PDFs from the repository
- Definitions/        official MDPI class files (version 13 March 2026)
- main.pdf            compiled manuscript

Before submission, add the department and postcode to the affiliation in main.tex.

## Revision 1 (reviewer response)
- `main.pdf`        marked version: red = added, red strike-through = deleted,
                    red [note] = moved text, yellow = authors must fill/verify
- `main_clean.pdf`  same source without mark-up (yellow placeholders remain visible)
- Build clean:  pdflatex -jobname=main_clean "\def\cleanversion{1}\input{main}"
                bibtex main_clean; then pdflatex twice more with the same command
- Before resubmission: search the sources for \tbd and \tbdl and replace every one.
